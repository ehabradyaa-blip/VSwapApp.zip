package com.vswap.app

import android.os.Bundle
import android.widget.MediaController
import android.widget.VideoView
import androidx.activity.ComponentActivity
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.compose.setContent
import androidx.activity.result.contract.ActivityResultContracts
import androidx.activity.viewModels
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.verticalScroll
import androidx.compose.material3.*
import androidx.compose.runtime.Composable
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.unit.dp
import androidx.compose.ui.viewinterop.AndroidView

class MainActivity : ComponentActivity() {
    private val vm: MainViewModel by viewModels()
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContent { MaterialTheme { Screen(vm) } }
    }
}

@Composable
fun Screen(vm: MainViewModel) {
    val pickVideo = rememberLauncherForActivityResult(ActivityResultContracts.GetContent()) { vm.videoUri = it ?: vm.videoUri }
    val pickImage = rememberLauncherForActivityResult(ActivityResultContracts.GetContent()) { vm.imageUri = it ?: vm.imageUri }

    Surface(Modifier.fillMaxSize()) {
        Column(
            Modifier.verticalScroll(rememberScrollState()).statusBarsPadding().padding(16.dp),
            verticalArrangement = Arrangement.spacedBy(12.dp)
        ) {
            Text("VSwap - استبدال الأشخاص في الفيديو", style = MaterialTheme.typography.titleLarge)

            OutlinedTextField(vm.serverUrl, { vm.serverUrl = it }, Modifier.fillMaxWidth(),
                label = { Text("عنوان السيرفر (https://...)") }, singleLine = true, enabled = !vm.busy)
            OutlinedTextField(vm.apiKey, { vm.apiKey = it }, Modifier.fillMaxWidth(),
                label = { Text("API Key") }, singleLine = true, enabled = !vm.busy)

            Button({ pickVideo.launch("video/*") }, Modifier.fillMaxWidth(), enabled = !vm.busy) {
                Text(if (vm.videoUri == null) "1) اختار الفيديو" else "الفيديو اتحدد ✅")
            }
            Button({ pickImage.launch("image/*") }, Modifier.fillMaxWidth(), enabled = !vm.busy) {
                Text(if (vm.imageUri == null) "2) اختار صورة الشخص الجديد" else "الصورة اتحددت ✅")
            }

            Row(verticalAlignment = Alignment.CenterVertically) {
                Switch(vm.fullReplace, { vm.fullReplace = it }, enabled = !vm.busy)
                Spacer(Modifier.width(8.dp))
                Text(if (vm.fullReplace) "استبدال كامل (جسم + وش)" else "تحريك الصورة بحركة الفيديو")
            }
            Row(verticalAlignment = Alignment.CenterVertically) {
                Switch(vm.enhance, { vm.enhance = it }, enabled = !vm.busy)
                Spacer(Modifier.width(8.dp))
                Text("ترميم الوش (أبطأ وأحسن جودة)")
            }

            Button({ vm.start() }, Modifier.fillMaxWidth(), enabled = !vm.busy) { Text("ابدأ المعالجة") }

            if (vm.busy || vm.stage.isNotEmpty()) {
                Text(vm.stage)
                if (vm.busy) LinearProgressIndicator(progress = { vm.progress }, modifier = Modifier.fillMaxWidth())
            }
            vm.message?.let { Text(it, color = MaterialTheme.colorScheme.primary) }

            vm.result?.let { file ->
                AndroidView(
                    factory = { ctx ->
                        VideoView(ctx).apply {
                            setMediaController(MediaController(ctx).also { it.setAnchorView(this) })
                            setVideoPath(file.absolutePath)
                            setOnPreparedListener { it.isLooping = true; start() }
                        }
                    },
                    modifier = Modifier.fillMaxWidth().height(320.dp)
                )
                Button({ vm.saveToGallery() }, Modifier.fillMaxWidth()) { Text("حفظ في المعرض") }
            }

            Text("استخدم صور ناس موافقين فقط، وما تنشرش فيديوهات تنسب كلام أو فعل لشخص حقيقي من غير إذنه.",
                style = MaterialTheme.typography.bodySmall)
        }
    }
}
