package com.vswap.app

import android.app.Application
import android.content.ContentValues
import android.net.Uri
import android.provider.MediaStore
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.setValue
import androidx.lifecycle.AndroidViewModel
import androidx.lifecycle.viewModelScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.delay
import kotlinx.coroutines.launch
import java.io.File

class MainViewModel(app: Application) : AndroidViewModel(app) {
    private val prefs = app.getSharedPreferences("vswap", 0)

    var serverUrl by mutableStateOf(prefs.getString("url", "") ?: "")
    var apiKey by mutableStateOf(prefs.getString("key", "") ?: "")
    var videoUri by mutableStateOf<Uri?>(null)
    var imageUri by mutableStateOf<Uri?>(null)
    var fullReplace by mutableStateOf(true)      // true = استبدال كامل، false = تحريك الصورة
    var enhance by mutableStateOf(true)
    var busy by mutableStateOf(false)
    var stage by mutableStateOf("")
    var progress by mutableStateOf(0f)
    var message by mutableStateOf<String?>(null)
    var result by mutableStateOf<File?>(null)

    init {
        // لو التطبيق اتقفل أثناء مهمة شغالة، كمّل متابعتها
        prefs.getString("job", null)?.let { resume(it) }
    }

    private fun api() = Api(serverUrl, apiKey)

    fun start() {
        val v = videoUri; val i = imageUri
        if (v == null || i == null) { message = "اختار الفيديو والصورة الأول"; return }
        if (serverUrl.isBlank()) { message = "اكتب عنوان السيرفر"; return }
        prefs.edit().putString("url", serverUrl).putString("key", apiKey).apply()
        busy = true; result = null; message = null; stage = "جاري الرفع..."; progress = 0f
        viewModelScope.launch(Dispatchers.IO) {
            try {
                val id = api().createJob(getApplication(), v, i, if (fullReplace) "replace" else "animate", enhance)
                prefs.edit().putString("job", id).apply()
                poll(id)
            } catch (e: Exception) { fail(e) }
        }
    }

    private fun resume(id: String) {
        busy = true; stage = "متابعة المهمة..."
        viewModelScope.launch(Dispatchers.IO) { try { poll(id) } catch (e: Exception) { fail(e) } }
    }

    private suspend fun poll(id: String) {
        while (true) {
            val s = api().status(id)
            stage = s.stage; progress = s.progress
            when (s.status) {
                "done" -> {
                    stage = "جاري تنزيل النتيجة..."
                    result = api().downloadResult(getApplication(), id)
                    prefs.edit().remove("job").apply()
                    busy = false; stage = "تم ✅"; return
                }
                "failed" -> { prefs.edit().remove("job").apply(); busy = false; message = "فشلت المعالجة: ${s.error}"; return }
            }
            delay(3000)
        }
    }

    private fun fail(e: Exception) { busy = false; message = "خطأ: ${e.message}" }

    fun saveToGallery() {
        val f = result ?: return
        val cv = ContentValues().apply {
            put(MediaStore.Video.Media.DISPLAY_NAME, "vswap_${System.currentTimeMillis()}.mp4")
            put(MediaStore.Video.Media.MIME_TYPE, "video/mp4")
            put(MediaStore.Video.Media.RELATIVE_PATH, "Movies/VSwap")
        }
        val res = getApplication<Application>().contentResolver
        val uri = res.insert(MediaStore.Video.Media.EXTERNAL_CONTENT_URI, cv)
        if (uri == null) { message = "تعذر الحفظ"; return }
        res.openOutputStream(uri)!!.use { o -> f.inputStream().use { it.copyTo(o) } }
        message = "اتحفظ في المعرض (Movies/VSwap)"
    }
}
