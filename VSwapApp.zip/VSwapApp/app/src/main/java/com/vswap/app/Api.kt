package com.vswap.app

import android.content.Context
import android.net.Uri
import okhttp3.*
import okhttp3.MediaType.Companion.toMediaType
import okio.BufferedSink
import okio.source
import org.json.JSONObject
import java.io.File
import java.util.concurrent.TimeUnit

data class JobState(val status: String, val stage: String, val progress: Float, val error: String?)

class Api(base: String, private val key: String) {
    private val base = base.trim().trimEnd('/')
    private val client = OkHttpClient.Builder()
        .connectTimeout(30, TimeUnit.SECONDS)
        .writeTimeout(15, TimeUnit.MINUTES)
        .readTimeout(15, TimeUnit.MINUTES)
        .build()

    private fun uriBody(ctx: Context, uri: Uri, type: MediaType) = object : RequestBody() {
        override fun contentType() = type
        override fun writeTo(sink: BufferedSink) {
            ctx.contentResolver.openInputStream(uri)!!.use { sink.writeAll(it.source()) }
        }
    }

    /** يرفع الفيديو والصورة ويرجّع job_id */
    fun createJob(ctx: Context, video: Uri, image: Uri, mode: String, enhance: Boolean): String {
        val imgType = ctx.contentResolver.getType(image) ?: "image/jpeg"
        val imgName = if (imgType.contains("png")) "ref.png" else "ref.jpg"
        val body = MultipartBody.Builder().setType(MultipartBody.FORM)
            .addFormDataPart("video", "input.mp4", uriBody(ctx, video, "video/mp4".toMediaType()))
            .addFormDataPart("image", imgName, uriBody(ctx, image, imgType.toMediaType()))
            .addFormDataPart("mode", mode)
            .addFormDataPart("enhance", enhance.toString())
            .build()
        val req = Request.Builder().url("$base/jobs").header("x-api-key", key).post(body).build()
        client.newCall(req).execute().use { r ->
            val txt = r.body?.string().orEmpty()
            if (!r.isSuccessful) error("رفض السيرفر (${r.code}): $txt")
            return JSONObject(txt).getString("job_id")
        }
    }

    fun status(jobId: String): JobState {
        val req = Request.Builder().url("$base/jobs/$jobId").header("x-api-key", key).build()
        client.newCall(req).execute().use { r ->
            val txt = r.body?.string().orEmpty()
            if (!r.isSuccessful) error("خطأ ${r.code}: $txt")
            val j = JSONObject(txt)
            return JobState(
                j.optString("status"), j.optString("stage"),
                j.optDouble("progress", 0.0).toFloat(),
                if (j.has("error")) j.getString("error") else null
            )
        }
    }

    fun downloadResult(ctx: Context, jobId: String): File {
        val req = Request.Builder().url("$base/jobs/$jobId/result").header("x-api-key", key).build()
        val out = File(ctx.cacheDir, "result_$jobId.mp4")
        client.newCall(req).execute().use { r ->
            if (!r.isSuccessful) error("فشل تنزيل النتيجة (${r.code})")
            out.outputStream().use { o -> r.body!!.byteStream().copyTo(o) }
        }
        return out
    }
}
